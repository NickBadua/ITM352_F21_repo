var express = require('express');
var app = express(); //places express function in app variable

// Routing 

// monitor all requests
app.all('*', function (request, response, next) {
   console.log(request.method + ' to ' + request.path);
   next();
});

var products_array = require('./products_data.json'); //Adapted from lab13
products_array.forEach((products_array, i) => { products_array.total_sold = 0 });

app.get("/products_data.js", function (request, response, next) { //Adapted from lab13. Responds to the get request on the the client pages to respond with the products data from json file.
    response.type('.js');
    var products_str = `var products_array = ${JSON.stringify(products_array)};`;
    response.send(products_str);
    next();
});

app.use(express.urlencoded({extended:true}));

// process purchase request (validate quantities, check quantity available)
app.post('/purchase', function (request, response, next) { //Adapted from lab 13 Exercise 5
    for (i in products_array) { //loop to go through all textboxes on products_display page
    var q = request.body[`quantity${i}`]; //gets textbox value through the object and places it in a variable
    response.send(`invoice.html?quantity${i}=` + q); //find way to keep adding "quantity${}=" to query string
}; 

});

// route all other GET requests to files in public 
app.use(express.static('./public'));

// start server
app.listen(8080, () => console.log(`listening on port 8080`));


//FUNCTION

function isNonNegInt(q, returnErrors = false) {
    //Checks if a string q is a non-neg integer. If returnErrors is ture, the array of errors is erturned, otherwise, returns true q is non-neg int.
    errors = []; // assume no errors at first
    if (Number(q) != q) errors.push('Not a number!'); // Check if string is a number value
    else {
        if (q < 0) errors.push('Negative value!'); // Check if it is non-negative
        if (parseInt(q) != q) errors.push('Not an integer!'); // Check that it is an integer
    }
    return (returnErrors ? errors : (errors.length == 0));
}

